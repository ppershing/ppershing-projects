Microsoft Visual C++ 6.0 SP5 Instructions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

- Double click on 'SDL_draw.dsw'

- Go to menu Build -> Batch Build... and push on the button 'Rebuild All'

- The static and dynamic libraries are in directory 'libs' and the 
  executable 'sdldrawtest.exe' are in this main directory 
  (also, you need SDL.dll in this directory to run sdldrawtest.exe).

