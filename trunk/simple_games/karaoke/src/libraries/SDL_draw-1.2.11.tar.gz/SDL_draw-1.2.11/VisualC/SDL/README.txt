Put here the SDL headers files under a directory 'include',
and the SDL library files under a directory 'lib' (files SDL.lib and SDLmain.lib).
Also put SDL.dll in VisualC main directory.

You can get SDL development files for Windows from: http://www.libsdl.org/

