// created and maintained by miso
// please report any bug or suggestion to miso<>ksp<>sk

#include <string>
#include "Syllable.h"

Syllable::Syllable(){
  start=0;
  duration=0;
  text="";
}

Syllable::~Syllable(){
}

