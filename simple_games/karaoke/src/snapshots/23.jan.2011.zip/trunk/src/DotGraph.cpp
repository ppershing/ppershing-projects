// created and maintained by ppershing
// please report any bug or suggestion to ppershing<>fks<>sk

#include "DotGraph.h"

// {{{ DotGraph
DotGraph::DotGraph():Graph(){
    R=G=B=A=255;
    ymin=0;
    ymax=1;
    auto_ymin=auto_ymax=1;
}
// }}}
