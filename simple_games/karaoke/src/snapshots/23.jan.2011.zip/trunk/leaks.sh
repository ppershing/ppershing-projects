./parse_leaks.pl Karaoke.exe Karaoke.leaks
