// created and maintained by ppershing
// please report any bug or suggestion to ppershing<>fks<>sk

//#ifndef H_DEBUG
//#define H_DEBUG

/**
  Debug macro - no debug at all
  */
#define DEBUG(X) ;

//#endif
